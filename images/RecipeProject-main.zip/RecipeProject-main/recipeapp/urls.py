from django.urls import path
from recipeapp import views

urlpatterns = [
    path('', views.home , name = 'home'),
    path('register/', views.registration, name="registration"),
    path('login/', views.login , name = 'login'),
    path('email_verify/', views.email_verify, name = 'email_verify'),
    path('otp_screen/', views.otp_screen, name = 'otp_screen'),
    path('reset_password/<str:email>/', views.reset_password, name= 'reset_password'),
    path('contact_us', views.contact_us, name='contact_us'),
    path('about_us', views.about_us, name = 'about_us'),
    path('recipe_description/<int:recipe_id>/', views.recipe_description , name = "recipe_description"),
    path('user_logout', views.user_logout , name = 'user_logout'),
    path('chatbot', views.chatbot , name = 'chatbot'),



]