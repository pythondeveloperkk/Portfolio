from django.shortcuts import render, redirect
from .models import register , recipedetail, recipes
from django.contrib.auth.hashers import make_password
from django.contrib import messages
from django.contrib.auth import authenticate, logout
from django.contrib.auth import  login as userlogin
import random
from django.core.mail import EmailMessage
from datetime import datetime, timedelta
import datetime 
from django.utils import timezone
import openai
from django.http import JsonResponse
from django.template.defaultfilters import linebreaksbr

openai.api_key = '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'


#Login
def login (request):
    """This method will hold the code to login the user

    Args:
        request : client to server connection

    Returns:
        Homepage : successful login will redirect the user to home page 

    """
    if request.user.is_authenticated:
        messages.success(request, "Already logged in !")
        return redirect('home')
    else:
        if request.method == 'POST':
            username = request.POST.get('email')
            password = request.POST.get('password')
            if not username:
                messages.error(request, "Username field is Empty")
            elif not password:
                messages.error(request, "Password field is Empty")    
            user = authenticate(request, username=username, password=password)
            if user is not None:
                if user.token is None:
                    userlogin(request, user)
                    messages.success(request, "Logged in Successfully")
                    return redirect('/')
                else:
                    messages.error(request, "User not varified")
                    return redirect('otp_screen')
            else:
                messages.error(request, "Invalid Username or Password")
    return render(request, 'login.html')


#Registration
def registration(request):
    """This method will hold the code to register the user

    Args:
        request : client to server connection

    Returns:
        login : if user got registered successfully he/she will be redirected to login screen

    """
    token = random.randint(1111, 9999)
    if request.method == 'POST':
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        email = request.POST.get('email')
        username = request.POST.get('username')
        password =  request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        if not firstname:
            messages.error(request, "Please input first name")
        elif not lastname:
            messages.error(request, "Please input Last Name")
        elif not email:
            messages.error(request, "Please input Email")
        elif register.objects.filter(email =  email).exists():
            messages.error(request, "Email already taken")
        elif not username:
            messages.error(request, "Please input Uasename")
        elif register.objects.filter(username =  username):
            messages.error(request, "Username already taken")
        elif len(password) < 8:
            messages.error(request, "Password should atleast contain 8 character's")
        elif password == confirm_password:
            messages.error(request, "Password doesnot match")
        else:
            register.objects.create(
                first_name = firstname,
                last_name = lastname,
                email = email,
                username = username,
                password = make_password(password),
                token = token,
                )
            
            subject = 'Reset password'          
            message = f"your reset password otp in {token}"   
            from_email = 'recordsdevelopment@gmail.com' 
            email = EmailMessage(subject, message, from_email, [email])   
            email.send()   
            messages.error(request, "Please verify email")
            return redirect('otp_screen') 
    return render(request, 'register.html')


# Email verification
def email_verify(request):
    """This method will hold the code to Verify if email exists in database,
    to generate & send otp to your mail and expire otp after 1 minute

    Args:
        request: client to server connection

    Returns:
        OTP Screen: if the user enters the correct email, he/she will be sent to
        the OTP screen to verify their respective OTP

    """
    token = random.randint(1111, 9999)
    if request.method == "POST":
        reset_email = request.POST.get('resetmail')
        if register.objects.filter(email=reset_email).exists():
            subject = 'Reset password'
            message = f"your reset password OTP is {token}"
            from_email = 'recordsdevelopment@gmail.com'
            email = EmailMessage(subject, message, from_email, [reset_email])
            email.send()

            # otp token creation time save
            first_mail = register.objects.filter(email=reset_email).first()
            first_mail.token = token
            first_mail.token_time = timezone.now() + timedelta(seconds=60)
            first_mail.forget_password = True
            first_mail.save()
            messages.success(request, "OTP sent!")
            return redirect('otp_screen')
    return render(request, 'email_verify.html')



# OTP verification
def otp_screen(request):
    """This method will hold the code to Verify if otp recieved by the user through mail matches with token(otp) stored in database 

    Args:
        request : client to server connection

    Returns:
        Reset password/ landing page  : user will either redirected to Reset password page or landing page as per the case  

    """
    if request.method == "POST":
        otp = request.POST.get('OTP')
        user = register.objects.filter(token = otp).first()
        email = None
        if user:
            if user.forget_password == True:
                if user.token_time > timezone.now():
                    email = user.email
                    user.token = None
                    user.save()
                    return redirect('/reset_password/' + email)
                else:
                    messages.error(request, "OTP has been expired")
            else:
                if user.token_time > timezone.now():
                    user.token =  None
                    user.save()
                    return redirect('home')    
                else:
                    messages.error(request, "OTP has been expired")
        else:
            messages.error(request, "invalid otp")
    return render(request, 'otp_screen.html') 


# Change Password
def reset_password(request, email):
    """This method will hold the code to reset current password 

    Args:
        request : client to server connection

    Returns:
        login : user will redirected to login page to sign in through new password  

    """
    if request.method  ==  "POST":
        new_password = request.POST.get('pass1')
        confirm_password = request.POST.get('pass2')
        if new_password == confirm_password:
            new_password = make_password(new_password)
            user = register.objects.get(email = email)
            user.password = new_password
            user.forget_password =  False
            user.save()
            messages.success(request, "Password Reset Successful !")
            return redirect('login')
    return render(request,'reset_password.html')

# Contact Us
def contact_us(request):
    """This method will hold the code to send enquiry for bugs, fixes and improvements

    Args:
        request : client to server connection

    Returns:
        home: user will be sent back to homepage once an enquiry is made without any error
    """
    if request.method == 'POST':
        contact_email = request.POST.get('contactusemail') 
        contact_subject = request.POST.get('contactussubject')
        contact_message = request.POST.get('contactusmessagebox')
        subject = contact_subject         
        message = contact_message
        to_email =  'jatinsaini60@yopmail.com'
        email = EmailMessage(subject, message, contact_email, [to_email])   
        email.send()       
        messages.success(request, "Enquiry sent !")
        return redirect('home')
    return render(request,'contact_us.html')


def about_us(request):
    return render(request, 'about_us.html')



def chatbot(request):
    if request.method == 'POST':
        input_prompt = request.POST.get('user_input')
        prompt = f"write a complete recipe of {input_prompt} in points"
        
        # Assuming you have already imported openai
        response = openai.Completion.create(
            engine="gpt-3.5-turbo-instruct",
            prompt=prompt,
            max_tokens=3500,
            temperature=0.5,
        )
        
        combined_response = response.choices[0].text
        formatted_response = linebreaksbr(combined_response) if combined_response else None 

        return JsonResponse({'response': formatted_response})
    
    return JsonResponse({'error': 'Invalid request method'})

#Hopepage Recipes
def home(request):
    """This method will fetch recipe name , image and category from database and show it to user

    Args:
        request : client to server connection

    Returns:
        Recipes : Once recipes are added on admin panel, they will be visible on homepage
    """
    recipecard = recipes.objects.all()
    context = {'recipecard': recipecard }
    return render(request, 'landing_page.html', context)


# Recipe details
def recipe_description(request, recipe_id):
    """This method will fetch recipe name , recipe image, description . ingredients and Process  from database and show it to user

    Args:
        request : client to server connection

    Returns:
        Recipe Description page : if used add all recipe details he/she will be redirected to full recipe description page 
    """
    recipes = recipedetail.objects.filter(id = recipe_id)
    context = {'recipes': recipes}
    return render(request, 'recipe_description.html', context)


#Logout
def user_logout(request):
    """This method will hold the code to logout the user

    Args:
        request : client to server connection

    Returns:
        Login : if user logged out successfully he/she will be redirected to login screen

    """
    if request.user.is_authenticated :
       logout(request)
       messages.success(request, "Logged Out Successfully")
       return redirect('login')
    
