from django.contrib import admin
from .models import recipedetail, recipes

class RecipeDetailAdmin(admin.ModelAdmin):
    list_display = ('dish_name', 'servings', 'preptime', 'cooktime', 'totaltime')
    search_fields = ('dish_name', 'recipe_description', 'ingredients', 'process')

class RecipesAdmin(admin.ModelAdmin):
    list_display = ('recipe_name', 'recipe_category')
    search_fields = ('recipe_name', 'recipe_description')

admin.site.register(recipedetail, RecipeDetailAdmin)
admin.site.register(recipes, RecipesAdmin)
