from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

class register(AbstractUser):
    token = models.IntegerField(null=True)
    token_time = models.DateTimeField(null = True)
    forget_password = models.BooleanField(default = False)

class recipes(models.Model):
    recipe_image = models.ImageField(null = False, blank = False)
    recipe_category = models.CharField(max_length = 40, null = False , blank = False)
    recipe_name = models.CharField(max_length = 100, null = False , blank = False)

class recipedetail(models.Model):
    dish_name = models.CharField(max_length = 100, null = False , blank = False)
    dish_image = models.ImageField(null = True, blank = False)
    recipe_description = models.TextField(null = False, blank = False)
    servings = models.IntegerField(null = False)
    preptime = models.IntegerField(null = False)
    cooktime = models.IntegerField(null = False)
    totaltime = models.IntegerField(null = False)
    ingredients = models.TextField(null = False , blank = False)
    process = models.TextField(null = False , blank = False)
